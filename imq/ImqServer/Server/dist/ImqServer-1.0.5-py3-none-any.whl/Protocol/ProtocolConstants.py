import sys
import os
sys.path.append('../')
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

CONNECT = 'connect'
PUBLISH = 'publish'
SUBSCRIBE = 'subscribe'
ADD = 'add'
FORMAT = 'JSON'
VERSION = "1.0"
RESPONSE_MESSAGE = "//success"