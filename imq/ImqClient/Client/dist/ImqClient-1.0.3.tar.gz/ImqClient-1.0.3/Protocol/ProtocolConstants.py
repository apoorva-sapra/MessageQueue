CONNECT = 'connect'
PUBLISH = 'publish'
SUBSCRIBE = 'subscribe'
ADD = 'add'
FORMAT = 'JSON'
VERSION = "1.0"
RESPONSE_MESSAGE = "//success"